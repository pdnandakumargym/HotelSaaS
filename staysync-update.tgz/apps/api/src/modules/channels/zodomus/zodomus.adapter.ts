import type { Logger } from 'pino';
import type { AppConfig } from '../../../config/env.js';
import type {
  CallContext,
  CallRecorder,
  ChannelProvider,
  ProviderCallResult,
  ProviderConfigStatus,
  ReferenceKind,
} from '../channel-provider.js';
import { ZodomusClient, type FetchLike, type ZodomusReadOperation } from './zodomus.client.js';

const KIND_TO_OPERATION: Record<ReferenceKind, ZodomusReadOperation> = {
  account: 'account',
  channels: 'channels',
  currencies: 'currencies',
  price_models: 'priceModels',
};

/** Zodomus implementation of the ChannelProvider port (Milestone 4: read-only account calls). */
export class ZodomusAdapter implements ChannelProvider {
  readonly id = 'zodomus';
  readonly displayName = 'Zodomus';
  private readonly client: ZodomusClient | null;

  constructor(
    private readonly config: AppConfig['zodomus'],
    logger: Logger,
    recorder?: CallRecorder,
    fetchImpl?: FetchLike,
    clientOverrides: { maxRetries?: number; backoffMs?: number } = {},
  ) {
    this.client =
      config.enabled && config.credentialsConfigured
        ? new ZodomusClient({
            baseUrl: config.baseUrl,
            username: config.username ?? '',
            password: config.password ?? '',
            environment: config.environment,
            timeoutMs: config.timeoutMs,
            logger: logger.child({ module: 'zodomus' }),
            recorder,
            fetch: fetchImpl,
            ...clientOverrides,
          })
        : null;
  }

  configStatus(): ProviderConfigStatus {
    return {
      provider: this.id,
      displayName: this.displayName,
      enabled: this.config.enabled,
      environment: this.config.environment,
      baseUrl: this.config.baseUrl,
      credentialsConfigured: this.config.credentialsConfigured,
    };
  }

  isReady(): boolean {
    return this.client !== null;
  }

  testConnection(ctx: CallContext): Promise<ProviderCallResult> {
    // GET /account is the cheapest authenticated read: it proves reachability and valid credentials.
    return this.require().get('account', ctx);
  }

  fetchReference(kind: ReferenceKind, ctx: CallContext): Promise<ProviderCallResult> {
    return this.require().get(KIND_TO_OPERATION[kind], ctx);
  }

  private require(): ZodomusClient {
    if (!this.client) throw new Error('Zodomus is not enabled or not configured');
    return this.client;
  }
}
