import { Router } from 'express';
import { z } from 'zod';
import type { Database } from '../../infrastructure/db/prisma.js';
import { withTenant } from '../../infrastructure/db/tenant.js';
import { requireAuth, requirePlatformPermission } from '../../middleware/auth.js';
import { requireOrgPermission } from '../../middleware/org-access.js';
import { registry } from '../../openapi/registry.js';
import { AppError } from '../../shared/errors.js';
import { sendData } from '../../shared/http.js';
import { parseQuery } from '../../shared/validate.js';
import { requestMeta } from '../auth/auth.routes.js';
import { getSubscription } from '../subscriptions/plan-limits.js';
import { REFERENCE_KINDS, type ReferenceKind } from './channel-provider.js';
import type { IntegrationService } from './integration.service.js';

for (const [method, path, summary, tag] of [
  ['get', '/admin/integrations/zodomus', 'Zodomus configuration status and API health (no credentials)', 'Admin'],
  ['post', '/admin/integrations/zodomus/test', 'Test Connection: authenticated read-only call (GET /account)', 'Admin'],
  ['get', '/admin/integrations/zodomus/calls', 'Recent outbound calls (metadata only)', 'Admin'],
  ['get', '/admin/integrations/zodomus/reference/{kind}', 'Cached read-only reference data (account, channels, currencies, price_models)', 'Admin'],
  ['post', '/admin/integrations/zodomus/reference/{kind}/refresh', 'Fetch reference data from Zodomus and cache it (sanitized)', 'Admin'],
  ['get', '/organizations/{orgId}/channels', 'Channel availability for an organization (no fabricated connections)', 'Channels'],
] as const) {
  registry.registerPath({ method, path: `/api/v1${path}`, tags: [tag], summary, responses: { 200: { description: 'OK' }, 409: { description: 'Integration not configured' } } });
}

function kindParam(v: unknown): ReferenceKind {
  if (typeof v === 'string' && (REFERENCE_KINDS as readonly string[]).includes(v)) return v as ReferenceKind;
  throw new AppError(404, 'NOT_FOUND', 'Unknown reference data kind');
}

/** Mounted inside the admin router (which already requires a platform role and verified 2FA). */
export function adminIntegrationsRouter(integrations: IntegrationService): Router {
  const r = Router();
  r.use(requirePlatformPermission('admin.integration.read'));

  r.get('/zodomus', async (_req, res) => {
    sendData(res, { config: integrations.configStatus(), health: await integrations.health() });
  });

  r.get('/zodomus/calls', async (req, res) => {
    const { limit } = parseQuery(z.object({ limit: z.coerce.number().int().min(1).max(200).default(50) }), req);
    sendData(res, await integrations.recentCalls(limit));
  });

  r.get('/zodomus/reference/:kind', async (req, res) => {
    sendData(res, await integrations.reference(kindParam(req.params['kind'])));
  });

  // Read-only provider calls, but they spend the platform's Zodomus quota and are audited.
  r.post('/zodomus/test', requirePlatformPermission('admin.integration.manage'), async (req, res) => {
    sendData(res, await integrations.testConnection(req.auth!.user, requestMeta(req)));
  });

  r.post('/zodomus/reference/:kind/refresh', requirePlatformPermission('admin.integration.manage'), async (req, res) => {
    sendData(res, await integrations.refreshReference(kindParam(req.params['kind']), req.auth!.user, requestMeta(req)));
  });

  return r;
}

const OWNER_STATE = {
  connected: 'available',
  degraded: 'available',
  failing: 'unavailable',
  untested: 'not_verified',
  disabled: 'not_configured',
  not_configured: 'not_configured',
} as const;

/**
 * Owner view of channels. Shows whether the platform's Zodomus connection is available and which
 * channels Zodomus offers (cached by an admin). Property-to-OTA connections arrive with mapping in
 * Milestone 5, so none are reported here — the UI must never imply an OTA is connected.
 */
export function orgChannelsRouter(deps: { db: Database; integrations: IntegrationService }): Router {
  const { db, integrations } = deps;
  const r = Router({ mergeParams: true });
  r.use(requireAuth());

  r.get('/', requireOrgPermission('property.read'), async (req, res) => {
    const orgId = req.org!.organizationId;
    const [health, channels, sub, properties] = await Promise.all([
      integrations.health(),
      integrations.reference('channels'),
      withTenant(db, orgId, (tx) => getSubscription(tx, orgId)),
      withTenant(db, orgId, (tx) => tx.property.findMany({ orderBy: { name: 'asc' }, select: { id: true, name: true, status: true } })),
    ]);
    const cfg = integrations.configStatus();
    sendData(res, {
      provider: { displayName: cfg.displayName, environment: cfg.environment, state: OWNER_STATE[health.connection] },
      availableChannels: channels ? { items: channels.payload, itemCount: channels.itemCount, fetchedAt: channels.fetchedAt } : null,
      plan: { code: sub.plan.code, maxChannels: sub.plan.maxChannels, channelsInUse: 0 },
      properties: properties.map((p) => ({ ...p, connections: [] as never[] })),
      mapping: { available: false, plannedMilestone: 5, reason: 'Property and room mapping needs the authenticated Zodomus API reference.' },
    });
  });

  return r;
}
